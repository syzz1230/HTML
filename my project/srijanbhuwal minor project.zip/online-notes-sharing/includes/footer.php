 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i class="material-icons" style="color: Green;">COPYRIGHT</i> 2020 <u><b style="color: Red;"> Made By-Aswary Chandravanshi,Online Notes Sharing <br><a href="https://projectworlds.in">Aswary123@gmail.com (70004-92232)</a></b></u></p>
                </div>
            </div>
   </footer>